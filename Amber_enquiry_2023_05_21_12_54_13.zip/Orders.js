function Snake() {
      this.x = 0;
      this.y = 0;
      this.xspeed = 1;
      this.yspeed = 0;
      this.total = 0; 
      this.tail = [];
      this.score = 0;
  //general setups of the snake
    
  	  this.eat = function(pos) {
      let d = dist(this.x, this.y, pos.x, pos.y);
      let a = 0;
      if (d < 1) {
      this.total++;
      frameRate(this.tail.length+10);
      score.html (' ' + (this.tail.length+1));
      	return true;
      } else {
       	return false;
      }
  //eat function, everytime the snake eats a food, it gains a tail length and the score plus 1, the speed becomes faster
    } 
      this.dir = function(x, y) {
    	this.xspeed = x;
        this.yspeed = y;
    }
  //directions
   
    this.death = function() {
    	for (let i = 0; i < this.tail.length; i++) {
      	let pos = this.tail[i];
        let d = dist(this.x, this.y, pos.x, pos.y);
        if (d < 1) {
          this.total = 0;
          this.tail= [];
          noLoop();
    let finalscore = (score.html());
    score.html('GAME OVER! Your score was : ' + finalscore);
    }
  }
  //the snakes dies if it hits the wall or its body, the game stops and show the score
}
    
      this.update = function() {
      
    
      if (this.total === this.tail.length) {
      	for (let i = 0; i < this.tail.length-1; i++) { 
        	this.tail[i] = this.tail[i+1];
      	}
  //make the body able to get longer
		}   
      
      this.tail[this.total-1] = createVector(this.x, this.y);
      this.x = this.x + this.xspeed*scl;
      this.y = this.y + this.yspeed*scl;
      this.x = constrain(this.x, 0, width-scl);
      this.x = constrain(this.x, 0, height-scl);
      this.y = constrain(this.y, 0, width-scl);
      this.y = constrain(this.y, 0, height-scl);
    }
    //make the tail able to go with the body and head
    this.show = function () {
      fill(255);
      
      	for (let i = 0; i < this.tail.length; i++){
      		rect(this.tail[i].x, this.tail[i].y, scl, scl);
      	}
    //show the tails
      
        fill(255);
        rect(this.x, this.y, scl, scl);
    //the color of the snake
  }
}  