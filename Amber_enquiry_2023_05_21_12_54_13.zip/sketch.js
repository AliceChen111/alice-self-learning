let snake;
let scl = 20;
let food;
let img;
let score;
//setups

function preload() {
  img = loadImage ("apple.png")
}
//apple image

function setup() {
createCanvas(600, 600);
  score = createDiv('Score = 0');
  score.position(20, 20);
  score.id = 'score';
  score.style('color', 'white');
//score position
  img.resize(20, 20);
//resize the image
  snake = new Snake;
  frameRate(17);
  food = createVector(random(width), random(height));
  Grow();
}
//everytime the snake eats a food, it does the "grow" command

function Grow() {
let cols = floor(width/scl);
let rows = floor(height/scl);
food = createVector(floor(random(cols)),floor(random(rows)));
food.mult(scl);
}
//food randomly appears

function draw() {
background(150);
image(img, food.x, food.y);

if (snake.eat(food)) {
Grow();
}
snake.death();
snake.update();
snake.show();
//eat, grow, update, show commands

fill(255, 0, 0, 100);
rect(food.x, food.y, scl, scl);
//position, color and size of the food

if (keyIsDown(65)){
snake.dir(-1, 0);
}
if (keyIsDown(87)){
snake.dir(0, -1);
}
if (keyIsDown(83)){
snake.dir(0, 1);
}
if (keyIsDown(68)){
snake.dir(1, 0);
}
//press W,A,S,D to control the snake
}