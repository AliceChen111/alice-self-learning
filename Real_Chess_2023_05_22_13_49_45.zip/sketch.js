let mapPerLen = 80;//height of each block

//white pieces
let imgw1;
let imgw2;
let imgw3;
let imgw4;
let imgw5;
let imgw6;
//black pieces
let imgb1;
let imgb2;
let imgb3;
let imgb4;
let imgb5;
let imgb6;

// where you press the mouse
let posBeforeX;
let posBeforeY;
// where you release the mouse
let posAfterX;
let posAfterY;
// identify each piece on each block
let piece = [];

function preload(){
	//load images
	imgw1 = loadImage("w5.png");
	imgw2 = loadImage("w2.png");
	imgw3 = loadImage("w1.png");
	imgw4 = loadImage("w3.png");
	imgw5 = loadImage("w6.png");
	imgw6 = loadImage("w4.png");
	

	
	imgb1 = loadImage("b6.png");
	imgb2 = loadImage("b3.png");
	imgb3 = loadImage("b2.png");
	imgb4 = loadImage("b4.png");
	imgb5 = loadImage("b1.png");
	imgb6 = loadImage("b5.png");
	

}


function setup() {
	createCanvas(mapPerLen*8,mapPerLen*8);
	//0 means empty
	for(let i =0;i<64;i++){
		piece[i] = 0;
	}
	//let  1  2   3  4  5  6 represent different of white pieces
	piece[0] = 2;
	piece[1] = 3;
	piece[2] = 4;
	piece[3] = 5;
	piece[4] = 6;
	piece[5] = 4;
	piece[6] = 3;
	piece[7] = 2;
	for(let i =8;i<16;i++){
		piece[i] = 1;
	}
	//let  11  12   13  14  15  16 represent different black pieces
	for(let i =48;i<56;i++){
		piece[i] = 11;
	}
	piece[56] = 12;
	piece[57] = 13;
	piece[58] = 14;
	piece[59] = 15;
	piece[60] = 16;
	piece[61] = 14;
	piece[62] = 13;
	piece[63] = 12;
}

//draw the board
function drawMap(){
	//cols and rows
	for(let i =0;i<8;i++){
		for(let j =0;j<8;j++){
			//set the color of the board
			if(i%2 == 0){
				if(j%2 == 0){
					fill(211,163,118);
					rect(i*mapPerLen,j*mapPerLen,mapPerLen,mapPerLen);
				}else{
					fill(160,94,55);
					rect(i*mapPerLen,j*mapPerLen,mapPerLen,mapPerLen);
				}
			}else{
				if(j%2 == 0){
					fill(160,94,55);
					rect(i*mapPerLen,j*mapPerLen,mapPerLen,mapPerLen);
				}else{
					fill(211,163,118);
					rect(i*mapPerLen,j*mapPerLen,mapPerLen,mapPerLen);
				}
			}
				
		}
	}
}

//draw the pieces
function drawChess(){
	for(let i =0;i<64;i++){
		//replace i to rows and cols
		let line = i%8;
		let col = int(i/8);
		//use cases to represent different pieces
		switch(piece[i]){
			case 1:
			image(imgw6,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 2:
			image(imgw5,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 3:
			image(imgw4,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 4:
			image(imgw3,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 5:
			image(imgw2,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 6:
			image(imgw1,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 11:
			image(imgb6,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 12:
			image(imgb5,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 13:
			image(imgb4,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 14:
			image(imgb3,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 15:
			image(imgb2,(line)*mapPerLen,(col)*mapPerLen);
			break;
			case 16:
			image(imgb1,(line)*mapPerLen,(col)*mapPerLen);
			break;
			default:
			break;
		}
	}
}


function draw() {
	drawMap();
	drawChess();
}

function mousePressed() {
	posBeforeX = mouseX;
	posBeforeY = mouseY;
}

function mouseReleased(){
	posAfterX = mouseX;
	posAfterY = mouseY;
	
  //put the piece to where the mouse at when you release the mousepressed
	let beforeLine = int(posBeforeX/mapPerLen);
	let beforeCol =  int(posBeforeY/mapPerLen);
	let afterLine = int(posAfterX/mapPerLen);
	let afterCol = int(posAfterY/mapPerLen);
	//check if the pieces are from the same side, if is not, one piece can get there or take the opponent piece
	if(piece[beforeCol*8+beforeLine] == 1||piece[beforeCol*8+beforeLine]==2||piece[beforeCol*8+beforeLine]==3||piece[beforeCol*8+beforeLine]==4||piece[beforeCol*8+beforeLine]==5||piece[beforeCol*8+beforeLine]==6){
		if(piece[afterCol*8+afterLine]==1||piece[afterCol*8+afterLine]==2||piece[afterCol*8+afterLine]==3||piece[afterCol*8+afterLine]==4||piece[afterCol*8+afterLine]==5||piece[afterCol*8+afterLine]==6){
			//white
		}else{
			piece[afterCol*8+afterLine] = piece[beforeCol*8+beforeLine];
			piece[beforeCol*8+beforeLine] = 0;
		}
	}
	if(piece[beforeCol*8+beforeLine] == 11||piece[beforeCol*8+beforeLine]==12||piece[beforeCol*8+beforeLine]==13||piece[beforeCol*8+beforeLine]==14||piece[beforeCol*8+beforeLine]==15||piece[beforeCol*8+beforeLine]==16){
		if(piece[afterCol*8+afterLine]==11||piece[afterCol*8+afterLine]==12||piece[afterCol*8+afterLine]==13||piece[afterCol*8+afterLine]==14||piece[afterCol*8+afterLine]==15||piece[afterCol*8+afterLine]==16){
			//black
		}else{
			piece[afterCol*8+afterLine] = piece[beforeCol*8+beforeLine];
			piece[beforeCol*8+beforeLine] = 0;
		}
	}
}